class ElectronicItem extends Item {
    public ElectronicItem(String name, double price) {
        super(name, price);
    }

    @Override
    public String getCategory() {
        return "Electronic";
    }
}
