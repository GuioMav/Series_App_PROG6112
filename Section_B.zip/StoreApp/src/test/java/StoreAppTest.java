import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class StoreAppTest {
    private GroceryItem apple;
    private ElectronicItem headphones;
    private Cart cart;

    @Before
    public void setUp() {
        apple = new GroceryItem("Apple", 0.99);
        headphones = new ElectronicItem("Headphones", 19.99);
        cart = new Cart(10);
    }

    @Test
    public void testGroceryItemCategory() {
        assertEquals("Grocery", apple.getCategory());
    }

    @Test
    public void testElectronicItemCategory() {
        assertEquals("Electronic", headphones.getCategory());
    }

    @Test
    public void testItemNameAndPrice() {
        assertEquals("Apple", apple.getName());
        assertEquals(0.99, apple.getPrice(), 0.001);
        assertEquals("Headphones", headphones.getName());
        assertEquals(19.99, headphones.getPrice(), 0.001);
    }

    @Test
    public void testAddItemToCartAndTotal() {
        cart.addItem(apple, 2);
        cart.addItem(headphones, 1);

        double expectedTotal = 2 * 0.99 + 1 * 19.99;
        assertEquals(expectedTotal, cart.getTotal(), 0.001);
    }

    @Test
    public void testAddDuplicateItemUpdatesQuantity() {
        cart.addItem(apple, 1);
        cart.addItem(apple, 2);

        cart.addItem(headphones, 1);
        cart.addItem(headphones, 2);

        double expectedTotal = (3 * 0.99) + (3 * 19.99);
        assertEquals(expectedTotal, cart.getTotal(), 0.001);
    }

    @Test
    public void testCartCapacity() {
        Cart smallCart = new Cart(1);
        smallCart.addItem(apple, 1);
        // Should not allow more than 1 unique item
        smallCart.addItem(headphones, 1);
        assertEquals(0.99, smallCart.getTotal(), 0.001); // Only apple was added
    }
}