class Cart {
    private Item[] items;
    private int[] quantities;
    private int size;
    private int capacity;

    public Cart(int capacity) {
        this.capacity = capacity;
        this.items = new Item[capacity];
        this.quantities = new int[capacity];
        this.size = 0;
    }

    public void addItem(Item item, int quantity) {
        // Check if item already in cart
        for (int i = 0; i < size; i++) {
            if (items[i].getName().equals(item.getName())) {
                quantities[i] += quantity;
                return;
            }
        }
        // Else, add new item
        if (size < capacity) {
            items[size] = item;
            quantities[size] = quantity;
            size++;
        } else {
            System.out.println("Cart is full!");
        }
    }

    public double getTotal() {
        double total = 0;
        for (int i = 0; i < size; i++) {
            total += items[i].getPrice() * quantities[i];
        }
        return total;
    }

    public void printReceipt() {
        System.out.println("\n--- RECEIPT ---");
        System.out.printf("%-20s %-10s %-10s %-10s\n", "Item", "Category", "Qty", "Price");
        for (int i = 0; i < size; i++) {
            System.out.printf("%-20s %-10s %-10d $%-9.2f\n",
                    items[i].getName(),
                    items[i].getCategory(),
                    quantities[i],
                    items[i].getPrice() * quantities[i]);
        }
        System.out.println("-------------------------------");
        System.out.printf("TOTAL:\t\t\t   $%.2f\n", getTotal());
        System.out.println("-------------------------------");
        System.out.println("Thank you for shopping!");
    }
}
