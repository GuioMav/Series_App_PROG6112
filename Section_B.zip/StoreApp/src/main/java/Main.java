import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        Item[] storeItems = {
                new GroceryItem("Apple", 0.99),
                new GroceryItem("Milk", 2.49),
                new ElectronicItem("Headphones", 19.99),
                new ElectronicItem("Laptop", 499.99),
                new GroceryItem("Bread", 1.79)
        };

        Cart cart = new Cart(20);

        System.out.println("Welcome to the Store!");
        boolean shopping = true;
        while (shopping) {
            System.out.println("\nAvailable Items:");
            for (int i = 0; i < storeItems.length; i++) {
                System.out.printf("%d) %-15s ($%.2f) [%s]\n", i+1, storeItems[i].getName(), storeItems[i].getPrice(), storeItems[i].getCategory());
            }
            System.out.println("0) Checkout");

            System.out.print("Select item number to add to cart (0 to checkout): ");
            int choice = scanner.nextInt();
            if (choice == 0) {
                shopping = false;
                break;
            }
            if (choice < 1 || choice > storeItems.length) {
                System.out.println("Invalid choice. Try again.");
                continue;
            }
            System.out.print("How many? ");
            int qty = scanner.nextInt();
            if (qty < 1) {
                System.out.println("Quantity must be at least 1.");
                continue;
            }
            cart.addItem(storeItems[choice-1], qty);
            System.out.println("Added to cart.");
        }

        // Payment simulation
        System.out.printf("Your total is $%.2f. Please enter payment amount: $", cart.getTotal());
        double payment = scanner.nextDouble();
        while (payment < cart.getTotal()) {
            System.out.print("Insufficient payment. Please enter at least $" + cart.getTotal() + ": $");
            payment = scanner.nextDouble();
        }
        double change = payment - cart.getTotal();
        System.out.printf("Payment accepted. Change: $%.2f\n", change);

        // Print receipt
        System.out.print("Do you want to print the receipt? (y/n): ");
        String print = scanner.next();
        if (print.equalsIgnoreCase("y")) {
            cart.printReceipt();
        } else {
            System.out.println("Receipt not printed. Goodbye!");
        }
        scanner.close();
    }
}