# Store Receipt Console App

## Overview

This Java console application simulates a simple store checkout system. It demonstrates the use of **abstraction, inheritance**, and **advanced arrays** in object-oriented programming. The application allows a customer to select items, specify the quantity for each item, process payment, and optionally print a detailed receipt.

## User Flow

1. **Welcome Screen:** The user is greeted and shown a list of available items.
2. **Item Selection:** The user selects which items to purchase and how many of each.
3. **Checkout:** The user chooses to finish shopping and proceeds to checkout.
4. **Payment:** The user is prompted to enter a payment amount. If it's insufficient, they're prompted again.
5. **Receipt Option:** After a successful payment, the user is asked if they want to print a receipt.
6. **Receipt Generation:** If the user agrees, a formatted receipt is printed, detailing all purchases and the total cost.

## Class Breakdown

- **Item (abstract class):**
    - Represents a generic store item.
    - Contains properties for the item name and price.
    - Declares an abstract method for category retrieval.

- **GroceryItem (extends Item):**
    - Represents grocery items.
    - Implements the category method to return "Grocery".

- **ElectronicItem (extends Item):**
    - Represents electronic items.
    - Implements the category method to return "Electronic".

- **Cart:**
    - Manages the user's selected items and their quantities.
    - Uses arrays to store item references and quantities.
    - Calculates the total cost.
    - Provides a method to print the receipt in a formatted manner.

- **StoreApp (main class):**
    - Handles the application flow and user interaction.
    - Displays the inventory, processes user input for selection and quantity.
    - Manages payment and receipt printing options.

## Tools & Technologies Used

- **GitHub Copilot**
- **IntelliJ**
- **Git and GitHub**
- **OpenAI ChatGPT 4.1**

## Author

- **Author:** Manuel Mavungo | ST10466974
